#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/opt/flutter"
export "FLUTTER_APPLICATION_PATH=/tmp/arena/tenants/c8fe152f-7dda-4245-a19b-6e794eec076f/sessions/177e66ae-c7d5-48eb-97c3-6ae83ea426db/workspace/sinflix"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=/tmp/arena/tenants/c8fe152f-7dda-4245-a19b-6e794eec076f/sessions/177e66ae-c7d5-48eb-97c3-6ae83ea426db/workspace/sinflix/macos/Flutter/ephemeral/Packages/.packages/FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=0.1.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
